// Inicialización del mapa con LeafletJS
export function initMap() {
  const mapDiv = document.getElementById("map");

  if (!mapDiv) {
    console.error("No se encontró el contenedor del mapa");
    return;
  }

  // Crear mapa centrado en Bogotá
  const map = L.map(mapDiv).setView([4.60971, -74.08175], 13);

  // Cargar tiles de OpenStreetMap
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "© OpenStreetMap",
  }).addTo(map);

  // Marcador de ejemplo
  L.marker([4.60971, -74.08175])
    .addTo(map)
    .bindPopup("¡Estoy Aqui!")
    .openPopup();
}
