// Inicialización de la interfaz de usuario
export function initUI() {
  console.log("✅ UI inicializada");


}
